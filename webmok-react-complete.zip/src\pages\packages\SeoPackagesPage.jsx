import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  FaCheck,
  FaTimes,
  FaStar,
  FaShieldAlt,
  FaRocket,
  FaPhoneAlt,
  FaPaperPlane,
  FaArrowRight,
  FaChartLine,
  FaChevronDown,
  FaChevronUp,
  FaGlobeAmericas,
  FaWhatsapp,
  FaAward,
  FaGoogle,
  FaChevronRight,
  FaHeadset,
  FaClock,
  FaLaptopCode,
  FaCheckCircle
} from 'react-icons/fa';
import './SeoPackagesPage.css';

const SeoPackagesPage = ({ onOpenCallMe, onOpenEnquiry }) => {
  const [currency, setCurrency] = useState('INR');
  const [openFaq, setOpenFaq] = useState(0);

  const toggleFaq = (index) => {
    setOpenFaq(openFaq === index ? null : index);
  };

  const pageData = {
    name: "SEO Packages in India",
    tagline: "SEO PACKAGES INDIA · EST. 2018",
    heroTitleHighlight: "SEO Packages in India",
    shortName: "SEO",
    leadDesc: "Are you looking for performance-driven SEO packages to dominate competitive Google organic rankings and drive qualified buyer traffic?",
    bodyDesc: "WebMok offers 100% white-hat, ROI-focused SEO packages trusted and tested by 500+ businesses across India and worldwide. Contact us today to audit your search presence and get a tailored organic strategy to rank higher NOW!",
    stats: [
  {
    "num": "500+",
    "label": "Active Clients"
  },
  {
    "num": "1,500+",
    "label": "Projects Delivered"
  },
  {
    "num": "98%",
    "label": "Client Retention Rate"
  },
  {
    "num": "100%",
    "label": "Earned Result Guarantee"
  }
],
    plans: [
  {
    "id": "basic",
    "badge": "Best for Small Business",
    "name": "Basic SEO Plan",
    "inrPrice": "15,000",
    "usdPrice": "249",
    "period": "/ month",
    "desc": "Designed for local businesses, startups, and service providers aiming to rank on page 1 for targeted local & regional keywords.",
    "highlight": false,
    "features": [
      "Up to 15 Target Keywords",
      "Complete Technical SEO Audit",
      "On-Page Optimization (Up to 10 Pages)",
      "Google Business Profile (GMB) Optimization",
      "5 High-Authority Backlinks / Month",
      "2 SEO Blog Articles (1000+ Words Each)",
      "Title, Meta & Heading Tag Optimization",
      "Robots.txt & XML Sitemap Configuration",
      "Monthly Ranking & Traffic Telemetry Report",
      "Dedicated Account Manager & Email Support"
    ]
  },
  {
    "id": "advanced",
    "badge": "Best for Mid Size Business",
    "name": "Advanced SEO Plan",
    "inrPrice": "28,000",
    "usdPrice": "449",
    "period": "/ month",
    "desc": "Ideal for growing enterprises, multi-location brands, and competitive niches seeking rapid search dominance and revenue growth.",
    "highlight": true,
    "popularTag": "Most Popular",
    "features": [
      "Up to 35 Target Keywords",
      "Full Website Technical & Speed Audit",
      "On-Page Optimization (Up to 25 Pages)",
      "Schema & Structured Data Integration",
      "15 High-DA Manual Backlinks / Month",
      "4 Authority Editorial Articles / Month",
      "Competitor Keyword Gap Analysis",
      "Internal Linking & Content Silo Structuring",
      "Local Citations & Directory Listings (30+)",
      "Conversion Rate & Heatmap Analysis",
      "Bi-Weekly Progress & Telemetry Report",
      "Dedicated SEO Strategist & Priority Phone Support"
    ]
  },
  {
    "id": "ecommerce",
    "badge": "Best for eCommerce & Enterprise",
    "name": "eCommerce SEO Plan",
    "inrPrice": "45,000",
    "usdPrice": "699",
    "period": "/ month",
    "desc": "Comprehensive SEO architecture engineered specifically for online stores, Shopify/WooCommerce, and high-SKU digital marketplaces.",
    "highlight": false,
    "features": [
      "Up to 60+ Target Commercial Keywords",
      "Category & Product Page SEO Optimization (50+ Pages)",
      "Product Schema & Rich Snippets Implementation",
      "Faceted Navigation & Duplicate Content Resolution",
      "25+ Premium High-DA Outreach Backlinks",
      "6 High-Converting Blog & Buyer Guide Articles",
      "Site Speed & Core Web Vitals Optimization",
      "Competitor Backlink & Market Share Interception",
      "Google Merchant Center & Shopping Feed Audit",
      "E-Commerce Revenue & Attribution Telemetry",
      "Weekly Strategy Call & Dedicated Senior Lead"
    ]
  },
  {
    "id": "enterprise",
    "badge": "Custom Enterprise Scale",
    "name": "Enterprise SEO Plan",
    "inrPrice": "Custom",
    "usdPrice": "Custom",
    "period": "Tailored Scope",
    "desc": "Custom-crafted bespoke SEO campaigns for large corporations, global multi-lingual domains, and aggressive market leaders.",
    "highlight": false,
    "features": [
      "Unlimited / 100+ Competitive Keywords",
      "Full-Scale Headless & Dynamic CMS SEO",
      "International & Multi-Language hreflang Architecture",
      "AI Search Visibility (SearchGPT, Gemini, Perplexity)",
      "Custom Digital PR & High-Tier Media Placements",
      "Dedicated Squad (Strategist, Content Lead, Dev, QA)",
      "Custom Automated KPI Dashboard & Daily Live Alerts",
      "100% Earned Result SLA Commitment"
    ]
  }
],
    faqs: [
  {
    "q": "How quickly can we see organic ranking improvements?",
    "a": "Typically, initial keyword movements and technical crawl improvements appear within 30 to 60 days, with substantial organic traffic and lead increases compounding between months 3 and 6."
  },
  {
    "q": "Are all backlinks 100% white-hat and Google-safe?",
    "a": "Yes. We strictly adhere to Google Search Essentials. We only acquire contextual, high-DA backlinks through authentic editorial outreach and original content publishing."
  },
  {
    "q": "Do your SEO plans have any mandatory lock-in contracts?",
    "a": "No! All our SEO plans operate on a flexible month-to-month billing schedule. You stay because you see measurable rankings and ROI, not because of a locked contract."
  },
  {
    "q": "Will I receive regular reporting on rankings and traffic?",
    "a": "Yes! You receive automated real-time telemetry dashboards plus detailed bi-weekly and monthly reports highlighting keyword positions, search impressions, organic visits, and conversion attribution."
  },
  {
    "q": "Can WebMok optimize our existing website or do we need a new one?",
    "a": "We work directly on your existing website (WordPress, Shopify, React, Next.js, Custom PHP, etc.), performing technical fixes and on-page optimization without disrupting live operations."
  }
]
  };

  return (
    <div className="wm-pkg-page-root">
      {/* 1. HERO SECTION (MATCHING SCREENSHOT REFERENCE) */}
      <section className="wm-pkg-hero-section">
        <div className="wm-pkg-container">
          <div className="wm-pkg-hero-grid">
            {/* Left Column: Heading, Copy, & Buttons */}
            <div className="wm-pkg-hero-left">
              <span className="wm-pkg-hero-est-tag">{pageData.tagline}</span>

              <h1 className="wm-pkg-hero-title-dual">
                <span className="wm-hero-italic-orange">Make Your Business Stand Out Using</span>
                <span className="wm-hero-bold-dark">{pageData.heroTitleHighlight}</span>
              </h1>

              <p className="wm-pkg-hero-lead-desc">{pageData.leadDesc}</p>
              <p className="wm-pkg-hero-body-desc">{pageData.bodyDesc}</p>

              <div className="wm-pkg-hero-btns-row">
                <button
                  type="button"
                  className="wm-pkg-btn-case-study"
                  onClick={() => onOpenEnquiry && onOpenEnquiry(`${pageData.name} - Free Audit / Case Study`)}
                >
                  {pageData.shortName} Case Study <FaPaperPlane />
                </button>
                <a href="#pricing-plans" className="wm-pkg-btn-packages-outline">
                  {pageData.shortName} Packages <FaChevronRight />
                </a>
              </div>
            </div>

            {/* Right Column: 4 Credibility / Review Cards Stack */}
            <div className="wm-pkg-hero-right-trust">
              <div className="wm-pkg-trust-card">
                <div className="wm-pkg-tcard-info">
                  <h4>#1 SEO Company</h4>
                  <p>Clutch · India 2025</p>
                </div>
                <div className="wm-pkg-tcard-icon-badge wm-badge-clutch">C</div>
              </div>

              <div className="wm-pkg-trust-card">
                <div className="wm-pkg-tcard-info">
                  <h4>Top-Rated Plus</h4>
                  <p>On Upwork</p>
                </div>
                <div className="wm-pkg-tcard-icon-badge wm-badge-upwork">up</div>
              </div>

              <div className="wm-pkg-trust-card">
                <div className="wm-pkg-tcard-info">
                  <h4>4.9 / 5</h4>
                  <p>
                    Google Reviews · 130+{' '}
                    <span className="wm-pkg-tcard-stars">
                      <FaStar /><FaStar /><FaStar /><FaStar /><FaStar />
                    </span>
                  </p>
                </div>
                <div className="wm-pkg-tcard-icon-badge wm-badge-google-stars">
                  <FaGoogle />
                </div>
              </div>

              <div className="wm-pkg-trust-card">
                <div className="wm-pkg-tcard-info">
                  <h4>Google Partner</h4>
                  <p>Certified Agency</p>
                </div>
                <div className="wm-pkg-tcard-icon-badge wm-badge-google-partner">
                  <FaAward />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. STATS STRIP */}
      <section className="wm-pkg-stats-strip">
        <div className="wm-pkg-container">
          <div className="wm-pkg-stats-grid">
            {pageData.stats.map((st, i) => (
              <div key={i} className="wm-pkg-stat-card">
                <strong>{st.num}</strong>
                <span>{st.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 3. TIERED PRICING PLANS SECTION */}
      <section className="wm-pkg-pricing-section" id="pricing-plans">
        <div className="wm-pkg-container">
          <div className="wm-pkg-sec-header">
            <span className="wm-pkg-subtitle">Transparent Pricing</span>
            <h2 className="wm-pkg-sec-title">Flexible Monthly {pageData.shortName} Plans with Zero Lock-In</h2>
            <div className="wm-pkg-bar"></div>
            <p className="wm-pkg-sec-desc">
              Choose the ideal performance plan tailored to your business scale, target keywords, and market competition.
            </p>

            {/* Currency Switcher */}
            <div className="wm-pkg-currency-toggle">
              <button
                type="button"
                className={`wm-curr-btn ${currency === 'INR' ? 'active' : ''}`}
                onClick={() => setCurrency('INR')}
              >
                ₹ INR (India)
              </button>
              <button
                type="button"
                className={`wm-curr-btn ${currency === 'USD' ? 'active' : ''}`}
                onClick={() => setCurrency('USD')}
              >
                $ USD (Global)
              </button>
            </div>
          </div>

          {/* Pricing Grid */}
          <div className={`wm-pkg-cards-grid wm-grid-${pageData.plans.length}`}>
            {pageData.plans.map((plan, i) => {
              const displayPrice = currency === 'INR' ? `₹${plan.inrPrice}` : `$${plan.usdPrice}`;
              return (
                <div key={i} className={`wm-pkg-card ${plan.highlight ? 'popular' : ''}`}>
                  {plan.highlight && (
                    <div className="wm-pkg-popular-tag">MOST POPULAR</div>
                  )}

                  <div className="wm-pkg-card-top">
                    {plan.badge && <span className="wm-pkg-plan-badge">{plan.badge}</span>}
                    <h3 className="wm-pkg-card-name">{plan.name}</h3>
                    <p className="wm-pkg-card-desc">{plan.desc}</p>
                  </div>

                  <div className="wm-pkg-card-pricing">
                    <div className="wm-pkg-price-row">
                      <span className="wm-pkg-price-val">{displayPrice}</span>
                      <span className="wm-pkg-price-period">{plan.period || '/ month'}</span>
                    </div>
                  </div>

                  <div className="wm-pkg-card-features">
                    <h4>What's Included:</h4>
                    <ul>
                      {plan.features.map((feat, fi) => (
                        <li key={fi}>
                          <FaCheck className="wm-feat-check" />
                          <span>{feat}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="wm-pkg-card-action">
                    <button
                      type="button"
                      className="wm-pkg-select-btn"
                      onClick={() => onOpenEnquiry && onOpenEnquiry(`${pageData.name} - ${plan.name}`)}
                    >
                      Choose Plan <FaArrowRight />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* 4. WHY CHOOSE WEBMOK */}
      <section className="wm-pkg-why-section">
        <div className="wm-pkg-container">
          <div className="wm-pkg-sec-header">
            <span className="wm-pkg-subtitle">Why Partner With Us</span>
            <h2 className="wm-pkg-sec-title">The WebMok Advantage in {pageData.shortName} Execution</h2>
            <div className="wm-pkg-bar"></div>
          </div>

          <div className="wm-pkg-why-grid">
            <div className="wm-pkg-why-card">
              <div className="wm-pkg-wicon"><FaShieldAlt /></div>
              <h4>100% White-Hat & Safe</h4>
              <p>Zero spam, zero shortcuts. We strictly execute high-grade, sustainable methods that protect your brand equity.</p>
            </div>

            <div className="wm-pkg-why-card">
              <div className="wm-pkg-wicon"><FaRocket /></div>
              <h4>Full Telemetry Reporting</h4>
              <p>Transparent bi-weekly and monthly dashboards tracking your key metrics, conversions, and direct ROI.</p>
            </div>

            <div className="wm-pkg-why-card">
              <div className="wm-pkg-wicon"><FaHeadset /></div>
              <h4>Dedicated Account Squad</h4>
              <p>Work directly with dedicated senior strategists, copywriters, and engineers with direct phone & Slack support.</p>
            </div>

            <div className="wm-pkg-why-card">
              <div className="wm-pkg-wicon"><FaClock /></div>
              <h4>Zero Mandatory Lock-In</h4>
              <p>Flexible month-to-month contracts. You continue because you see compounding results and profitable growth.</p>
            </div>
          </div>
        </div>
      </section>

      {/* 5. FAQS ACCORDION */}
      <section className="wm-pkg-faqs-section">
        <div className="wm-pkg-container">
          <div className="wm-pkg-sec-header">
            <span className="wm-pkg-subtitle">Frequently Asked Questions</span>
            <h2 className="wm-pkg-sec-title">Common Queries About {pageData.shortName} Packages</h2>
            <div className="wm-pkg-bar"></div>
          </div>

          <div className="wm-pkg-faqs-wrap">
            {pageData.faqs.map((faq, idx) => (
              <div
                key={idx}
                className={`wm-pkg-faq-item ${openFaq === idx ? 'open' : ''}`}
              >
                <button
                  type="button"
                  className="wm-pkg-faq-q"
                  onClick={() => toggleFaq(idx)}
                >
                  <span>{faq.q}</span>
                  {openFaq === idx ? <FaChevronUp /> : <FaChevronDown />}
                </button>
                {openFaq === idx && (
                  <div className="wm-pkg-faq-a">
                    <p>{faq.a}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 6. BOTTOM CONVERSION BANNER */}
      <section className="wm-pkg-bottom-banner">
        <div className="wm-pkg-container">
          <div className="wm-pkg-banner-inner">
            <div className="wm-pkg-banner-text">
              <h2>Ready to Accelerate Growth with Our {pageData.shortName} Packages?</h2>
              <p>Schedule a quick 1-on-1 audit with our senior specialists today. Get a customized campaign blueprint tailored to your targets.</p>
            </div>
            <div className="wm-pkg-banner-btns">
              <button
                type="button"
                className="wm-pkg-bbtn-call"
                onClick={onOpenCallMe}
              >
                <FaPhoneAlt /> Call in 28 Sec
              </button>
              <button
                type="button"
                className="wm-pkg-bbtn-quote"
                onClick={() => onOpenEnquiry && onOpenEnquiry(`${pageData.name} - Bottom Banner Inquiry`)}
              >
                Get Custom Quote <FaArrowRight />
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default SeoPackagesPage;
